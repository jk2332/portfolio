<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles" tilewidth="32" tileheight="32" tilecount="8" columns="4">
 <image source="tiled/tiles.png" width="128" height="64"/>
</tileset>
