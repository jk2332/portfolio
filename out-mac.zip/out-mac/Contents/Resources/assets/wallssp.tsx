<?xml version="1.0" encoding="UTF-8"?>
<tileset name="wallssp" tilewidth="64" tileheight="64" tilecount="4" columns="2">
 <image source="tiled/wallssp.png" width="128" height="128"/>
</tileset>
