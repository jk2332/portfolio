<?xml version="1.0" encoding="UTF-8"?>
<tileset name="wallsh" tilewidth="32" tileheight="64" tilecount="6" columns="3">
 <image source="tiled/wallsh.png" width="96" height="128"/>
</tileset>
