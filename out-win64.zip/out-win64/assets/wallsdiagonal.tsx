<?xml version="1.0" encoding="UTF-8"?>
<tileset name="wallsdiagonal" tilewidth="32" tileheight="96" tilecount="4" columns="2">
 <image source="tiled/wallsdiagonal.png" width="64" height="192"/>
</tileset>
