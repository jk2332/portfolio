<?xml version="1.0" encoding="UTF-8"?>
<tileset name="wallsv" tilewidth="32" tileheight="32" tilecount="2" columns="2">
 <image source="tiled/wallsv.png" width="64" height="32"/>
</tileset>
