<?xml version="1.0" encoding="UTF-8"?>
<tileset name="computer" tilewidth="64" tileheight="64" tilecount="1" columns="1">
 <image source="tiled/computer.png" width="64" height="64"/>
</tileset>
